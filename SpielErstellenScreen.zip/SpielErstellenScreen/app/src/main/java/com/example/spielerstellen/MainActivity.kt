package com.example.spielerstellen

import android.net.sip.SipSession
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var checked = 0
        cbmitspielen.setText("Dieses Gerät spielt nicht mit")
        cbmitspielen.setOnClickListener {
            when(checked) {
                0 -> {
                    checked = 1
                    cbmitspielen.setText("Dieses Gerät spielt mit")
                }
                1 -> {
                    checked = 0
                    cbmitspielen.setText("Dieses Gerät spielt nicht mit")
                }
            }
        }

    }
}
