package com.example.versuch1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.widget.Button
import android.widget.TextView

import kotlinx.android.synthetic.main.activity_main.*






class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val button1 = findViewById<Button>(R.id.btn_test)
        button1.setOnClickListener {
            textView1.text = "Test"
        }
        val button2 = findViewById<Button>(R.id.btn_test1)
        button2.setOnClickListener {
            textView1.text = "Dies ist ein Test"
        }


    }
}


      /*  buBtn.setOnClickListener {
            val textEins = "Test"

            tvAusgabe.text = textEins



            }*/

        /*  val Btn = findViewById<Button1>(R.id.Btn)
            val Txt = findViewById<TextView>(R.id.mTextView)
            Btn.run {
                setOnClickListener
                ("Dieser Button wurde geklickt")
            }*/




