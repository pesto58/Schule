package com.example.test2

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Datenbankklasse(context: Context):
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION){

    override fun onCreate(db: SQLiteDatabase) {
        val sql = "CREATE TABLE " +  TABLE_NAME + " (" +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        S_1 + " Integer NOT NULL, " +
                        S_2 + " Integer NOT NULL, " +
                        S_3 + " Integer NOT NULL, " +
                        S_4 + " Integer NOT NULL, " +
                        S_5 + " Integer NOT NULL, " +
                        S_6 + " Integer NOT NULL, " +
                        S_7 + " Integer NOT NULL, " +
                        S_8 + " Integer NOT NULL, " +
                        S_9 + " Integer NOT NULL " + ")"
        db.execSQL(sql)
    }

    override fun onUpgrade (db: SQLiteDatabase, versionAlt: Int, versionNeu: Int){
//       onUpgrade(db, versionAlt, versionNeu)
//        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME)
//        onCreate(db)
    }

    fun changeDS(s: Int, w: Int){
        val db = this.writableDatabase
        val values = ContentValues()
        when(s) {
            1 -> values.put(S_1, w)
            2 -> values.put(S_2, w)
            3 -> values.put(S_3, w)
            4 -> values.put(S_4, w)
            5 -> values.put(S_5, w)
            6 -> values.put(S_6, w)
            7 -> values.put(S_7, w)
            8 -> values.put(S_8, w)
            9 -> values.put(S_9, w)
        }
        val anzahl = db.update(TABLE_NAME,values,"",null)
        db.close()
    }

    // Datensatz wird zur Tabelle hinzugefügt
    fun addDS(w1: Int, w2: Int, w3: Int, w4: Int, w5: Int, w6: Int, w7: Int, w8: Int, w9: Int) {
        val values = ContentValues()
        values.put(S_1, w1)
        values.put(S_2, w2)
        values.put(S_3, w3)
        values.put(S_4, w4)
        values.put(S_5, w5)
        values.put(S_6, w6)
        values.put(S_7, w7)
        values.put(S_8, w8)
        values.put(S_9, w9)
        val db = this.writableDatabase
        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    // Die ganze Tabelle wird ausgelesen bzw. in einer Cursor-Variable zurückgegeben
    // Dargestellt werden die Daten durch die Funktion showDB in MainActivity
    fun auslesenDS(): Cursor {
        val db = this.readableDatabase
        return db.rawQuery("SELECT * FROM schalterzustaende ", null)
    }

    // Hier werden die wichtigen Daten in Variablen eines Companion-Objekts gesepeichert
    companion object {
        private val DATABASE_VERSION = 11
        private val DATABASE_NAME = "aufgabe1.db"
        val TABLE_NAME = "schalterzustaende"
        val COLUMN_ID = "id"
        val S_1 = "schalter1"
        val S_2 = "schalter2"
        val S_3 = "schalter3"
        val S_4 = "schalter4"
        val S_5 = "schalter5"
        val S_6 = "schalter6"
        val S_7 = "schalter7"
        val S_8 = "schalter8"
        val S_9 = "schalter9"
    }






}