package com.example.test2

import android.graphics.Color
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.TextView
import android.widget.ToggleButton
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    val datenbank = Datenbankklasse(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val bu_neuStart: Button = findViewById(R.id.bu_neuStart)
        val tb1B1: ToggleButton = findViewById(R.id.tb1B1)
        val tb1B2: ToggleButton = findViewById(R.id.tb1B2)
        val tb1B3: ToggleButton = findViewById(R.id.tb1B3)
        val tb1B4: ToggleButton = findViewById(R.id.tb1B4)
        val tb1B5: ToggleButton = findViewById(R.id.tb1B5)
        val tb1B6: ToggleButton = findViewById(R.id.tb1B6)
        val tb1B7: ToggleButton = findViewById(R.id.tb1B7)
        val tb1B8: ToggleButton = findViewById(R.id.tb1B8)
        val tb1B9: ToggleButton = findViewById(R.id.tb1B9)
        var tvAusgabe: TextView = findViewById(R.id.tvAusgabe)



        tvAusgabe.setMovementMethod(ScrollingMovementMethod())

        tvAusgabe.text = datenbank.databaseName + "\n"

        // wenn kein oder mehr als ein DS in Tabelle ist, dafuer sorgen, dass nur immer einer drin ist
        val leser = datenbank.readableDatabase
        val schreiber = datenbank.writableDatabase

        bu_neuStart.setOnClickListener{
            reset_Schalter()
        }

        val erg = leser.rawQuery("SELECT * FROM  schalterzustaende ", null)
        if (erg.count == 0){
            reset_Schalter()
        } else if (erg.count > 1){
            schreiber.delete("schalterzustaende","",null)
            reset_Schalter()
        } else {
            // die Schalter werden so gesetzt, wie es die Datenbank gespeichert hat
            while(erg.moveToNext()){
                if (erg.getInt(erg.getColumnIndex("schalter1")) == 1) tb1B1.setChecked(false) else tb1B1.setChecked(true)
                if (erg.getInt(erg.getColumnIndex("schalter2")) == 1) tb1B2.setChecked(false) else tb1B2.setChecked(true)
                if (erg.getInt(erg.getColumnIndex("schalter3")) == 1) tb1B3.setChecked(false) else tb1B3.setChecked(true)
                if (erg.getInt(erg.getColumnIndex("schalter4")) == 1) tb1B4.setChecked(false) else tb1B4.setChecked(true)
                if (erg.getInt(erg.getColumnIndex("schalter5")) == 1) tb1B5.setChecked(false) else tb1B5.setChecked(true)
                if (erg.getInt(erg.getColumnIndex("schalter6")) == 1) tb1B6.setChecked(false) else tb1B6.setChecked(true)
                if (erg.getInt(erg.getColumnIndex("schalter7")) == 1) tb1B7.setChecked(false) else tb1B7.setChecked(true)
                if (erg.getInt(erg.getColumnIndex("schalter8")) == 1) tb1B8.setChecked(false) else tb1B8.setChecked(true)
                if (erg.getInt(erg.getColumnIndex("schalter9")) == 1) tb1B9.setChecked(false) else tb1B9.setChecked(true)
            }
        }
        logik()
        showDB()

        tb1B1.setOnCheckedChangeListener { _, isChecked ->
            if (!isChecked) datenbank.changeDS(1,1) else datenbank.changeDS(1,0)
            logik()
            showDB()
        }

        tb1B2.setOnCheckedChangeListener { _, isChecked ->
            if (!isChecked) datenbank.changeDS(2,1) else datenbank.changeDS(2,0)
            logik()
            showDB()
        }

        tb1B3.setOnCheckedChangeListener { _, isChecked ->
            if (!isChecked) datenbank.changeDS(3,1) else datenbank.changeDS(3,0)
            logik()
            showDB()
        }

        tb1B4.setOnCheckedChangeListener { _, isChecked ->
            if (!isChecked) datenbank.changeDS(4,1) else datenbank.changeDS(4,0)
            logik()
            showDB()
        }

        tb1B5.setOnCheckedChangeListener { _, isChecked ->
            if (!isChecked) datenbank.changeDS(5,1) else datenbank.changeDS(5,0)
            logik()
            showDB()
        }

        tb1B6.setOnCheckedChangeListener { _, isChecked ->
            if (!isChecked) datenbank.changeDS(6,1) else datenbank.changeDS(6,0)
            logik()
            showDB()
        }

        tb1B7.setOnCheckedChangeListener { _, isChecked ->
            if (!isChecked) datenbank.changeDS(7,1) else datenbank.changeDS(7,0)
            logik()
            showDB()
        }

        tb1B8.setOnCheckedChangeListener { _, isChecked ->
            if (!isChecked) datenbank.changeDS(8,1) else datenbank.changeDS(8,0)
            logik()
            showDB()
        }

        tb1B9.setOnCheckedChangeListener { _, isChecked ->
            if (!isChecked) datenbank.changeDS(9,1) else datenbank.changeDS(9,0)
            logik()
            showDB()
        }


    }

    fun logik(){
        val tv1B1: TextView = findViewById(R.id.tv1B1)
        val tv1B2: TextView = findViewById(R.id.tv1B2)
        val tv1B3: TextView = findViewById(R.id.tv1B3)
        val tv1B4: TextView = findViewById(R.id.tv1B4)
        val tv1B5: TextView = findViewById(R.id.tv1B5)
        val tv1B6: TextView = findViewById(R.id.tv1B6)
        val tv1B7: TextView = findViewById(R.id.tv1B7)
        val tv1B8: TextView = findViewById(R.id.tv1B8)
        val tv1B9: TextView = findViewById(R.id.tv1B9)

        if (tb1B1.isChecked || (tb1B7.isChecked && tb1B8.isChecked) ) tv1B1.setTextColor(Color.rgb(0,200,0))
        else tv1B1.setTextColor(Color.rgb(200,0,0))

        if (!tb1B1.isChecked || tb1B2.isChecked || tb1B4.isChecked) tv1B2.setTextColor(Color.rgb(0,200,0))
        else tv1B2.setTextColor(Color.rgb(200,0,0))

        if (tb1B1.isChecked || tb1B6.isChecked ) tv1B3.setTextColor(Color.rgb(0,200,0))
        else tv1B3.setTextColor(Color.rgb(200,0,0))

        if (!tb1B6.isChecked || (tb1B7.isChecked && !tb1B5.isChecked)) tv1B4.setTextColor(Color.rgb(0,200,0))
        else tv1B4.setTextColor(Color.rgb(200,0,0))

        if (!tb1B9.isChecked || tb1B1.isChecked || tb1B3.isChecked) tv1B5.setTextColor(Color.rgb(0,200,0))
        else tv1B5.setTextColor(Color.rgb(200,0,0))

        if (!tb1B8.isChecked || !tb1B2.isChecked ) tv1B6.setTextColor(Color.rgb(0,200,0))
        else tv1B6.setTextColor(Color.rgb(200,0,0))

        if ((!tb1B3.isChecked && tb1B6.isChecked) || (tb1B8.isChecked && !tb1B4.isChecked)) tv1B7.setTextColor(Color.rgb(0,200,0))
        else tv1B7.setTextColor(Color.rgb(200,0,0))

        if (tb1B9.isChecked || (tb1B5.isChecked && !tb1B6.isChecked)) tv1B8.setTextColor(Color.rgb(0,200,0))
        else tv1B8.setTextColor(Color.rgb(200,0,0))

        if (!tb1B4.isChecked || (tb1B3.isChecked && !tb1B9.isChecked)) tv1B9.setTextColor(Color.rgb(0,200,0))
        else tv1B9.setTextColor(Color.rgb(200,0,0))
    }

    fun reset_Schalter(){
        datenbank.addDS(1,1,1,1,1,1,1,1,1)
        // Pfeile zeigen nach oben: false
        this.tb1B1.setChecked(false)
        this.tb1B2.setChecked(false)
        this.tb1B3.setChecked(false)
        this.tb1B4.setChecked(false)
        this.tb1B5.setChecked(false)
        this.tb1B6.setChecked(false)
        this.tb1B7.setChecked(false)
        this.tb1B8.setChecked(false)
        this.tb1B9.setChecked(false)
        this.tvAusgabe.text = ""
    }

    fun showDB(){
        var daten = ""
        val leser = datenbank.readableDatabase
        val erg = leser.rawQuery("SELECT * FROM  schalterzustaende ", null)

        if (erg.count == 0){
            daten += "keine Datensätze"
        } else {
            while (erg.moveToNext()){
                daten += erg.getInt(erg.getColumnIndex("schalter1")).toString() + " "
                daten += erg.getInt(erg.getColumnIndex("schalter2")).toString() + " "
                daten += erg.getInt(erg.getColumnIndex("schalter3")).toString() + " "
                daten += erg.getInt(erg.getColumnIndex("schalter4")).toString() + " "
                daten += erg.getInt(erg.getColumnIndex("schalter5")).toString() + " "
                daten += erg.getInt(erg.getColumnIndex("schalter6")).toString() + " "
                daten += erg.getInt(erg.getColumnIndex("schalter7")).toString() + " "
                daten += erg.getInt(erg.getColumnIndex("schalter8")).toString() + " "
                daten += erg.getInt(erg.getColumnIndex("schalter9")).toString() + "\n"
            }
        }
        daten = tvAusgabe.text.toString() + daten
        tvAusgabe.text = daten
    }
}

